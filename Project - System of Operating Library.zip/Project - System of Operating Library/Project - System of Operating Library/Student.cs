﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project___System_of_Operating_Library
{
    public class Student : User
    {
        private const int BorrowDays = 14;

        public Student(string name) : base(name) { }

        public override void BorrowBook(Library library, string title)
        {
            library.BorrowBook(title, BorrowDays);
            Console.WriteLine($"{Name} зае книгата \"{title}\"");
            Console.WriteLine($" Срок за връщане: {BorrowDays} дни");
        }

        public override void ReturnBook(Library library, string title)
        {
            library.ReturnBook(title);
            Console.WriteLine($"{Name} върна книгата \"{title}\"");
        }
    }
}

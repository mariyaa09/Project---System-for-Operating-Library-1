﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project___System_of_Operating_Library
{
    public class Librarian : User
    {
        public Librarian(string name) : base(name) { }

        public void AddBook(Library library, string title, string author)
        {
            library.AddBook(new Book(title, author));
            Console.WriteLine("Книгата е добавена успешно.");
        }

        public override void BorrowBook(Library library, string title)
        {
            Console.WriteLine("Библиотекарят няма право да заема книги.");
        }

        public override void ReturnBook(Library library, string title)
        {
            Console.WriteLine("Библиотекарят няма право да връща книги.");
        }
    }
}

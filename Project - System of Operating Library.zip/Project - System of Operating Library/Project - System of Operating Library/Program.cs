﻿using System;

namespace Project___System_of_Operating_Library
{
    class Program
    {
        static void Main(string[] args)
        {
            Library library = new Library();

            // Начални книги
            library.AddBook(new Book("Под игото", "Иван Вазов"));
            library.AddBook(new Book("1984", "Джордж Оруел"));
            library.AddBook(new Book("Малкият принц", "Антоан дьо Сент-Екзюпери"));
            library.AddBook(new Book("Хари Потър", "Дж. К. Роулинг"));
            library.AddBook(new Book("Властелинът на пръстените", "Дж. Р. Р. Толкин"));

            Console.WriteLine("=== СИСТЕМА ЗА УПРАВЛЕНИЕ НА БИБЛИОТЕКА ===");
            Console.WriteLine(" -- МЕНЮ --");

            Console.Write("Въведете име: ");
            string name = Console.ReadLine();

            Console.Write("Тип потребител (1 - Студент, 2 - Библиотекар): ");
            int type = int.Parse(Console.ReadLine());

            User user = type == 1 ? new Student(name) : new Librarian(name);

            while (true)
            {
                Console.WriteLine("\n1. Показване на книги");
                Console.WriteLine("2. Заемане на книга");
                Console.WriteLine("3. Връщане на книга");
                Console.WriteLine("4. Добавяне на книга (само библиотекар)");
                Console.WriteLine("0. Изход");
                Console.Write("Избор: ");

                string choice = Console.ReadLine();

                try
                {
                    switch (choice)
                    {
                        case "1":
                            library.ShowBooks();
                            break;

                        case "2":
                            Console.Write("Заглавие: ");
                            user.BorrowBook(library, Console.ReadLine());
                            break;

                        case "3":
                            Console.Write("Заглавие: ");
                            user.ReturnBook(library, Console.ReadLine());
                            break;

                        case "4":
                            if (user is Librarian librarian)
                            {
                                Console.Write("Заглавие: ");
                                string title = Console.ReadLine();
                                Console.Write("Автор: ");
                                string author = Console.ReadLine();
                                librarian.AddBook(library, title, author);
                            }
                            else
                                Console.WriteLine("Нямате права!");
                            break;

                        case "0":
                            return;

                        default:
                            Console.WriteLine("Невалиден избор.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("❌ Грешка: " + ex.Message);
                }
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project___System_of_Operating_Library
{
    public class BookNotAvailableException : Exception
    {
        public BookNotAvailableException(string message) : base(message) { }
    }
}

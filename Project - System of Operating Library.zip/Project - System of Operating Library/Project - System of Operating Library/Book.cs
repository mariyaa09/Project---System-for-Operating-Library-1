﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project___System_of_Operating_Library
{
    public class Book
    {
        public string Title { get; private set; }
        public string Author { get; private set; }
        public bool IsBorrowed { get; private set; }
        public DateTime? DueDate { get; private set; }

        public Book(string title, string author)
        {
            Title = title;
            Author = author;
            IsBorrowed = false;
            DueDate = null;
        }

        public void Borrow(int days)
        {
            if (IsBorrowed)
                throw new Exception("Книгата вече е заета.");

            IsBorrowed = true;
            DueDate = DateTime.Now.AddDays(days);
        }

        public void Return()
        {
            if (!IsBorrowed)
                throw new Exception("Книгата не е заета.");

            IsBorrowed = false;
            DueDate = null;
        }

        public override string ToString()
        {
            if (IsBorrowed)
                return $"{Title} - {Author} [Заета | Срок: {DueDate:dd.MM.yyyy}]";
            else
                return $"{Title} - {Author} [Налична]";
        
        }
    }
}

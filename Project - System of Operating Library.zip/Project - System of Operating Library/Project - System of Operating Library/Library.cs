﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project___System_of_Operating_Library
{
   public class Library
    {
        private List<Book> books = new List<Book>();

        public void AddBook(Book book)
        {
            books.Add(book);
        }

        public void ShowBooks()
        {
            if (books.Count == 0)
            {
                Console.WriteLine("Няма налични книги.");
                return;
            }

            Console.WriteLine("\n--- КНИГИ В БИБЛИОТЕКАТА ---");
            foreach (var book in books)
                Console.WriteLine(book);
        }

        public void BorrowBook(string title, int days)
        {
            Book book = books.FirstOrDefault(b => b.Title == title);

            if (book == null)
                throw new Exception("Книгата не съществува.");

            book.Borrow(days);
        }

        public void ReturnBook(string title)
        {
            Book book = books.FirstOrDefault(b => b.Title == title);

            if (book == null)
                throw new Exception("Книгата не съществува.");

            if (book.DueDate < DateTime.Now)
                Console.WriteLine("⚠ Книгата е върната след изтичане на срока!");

            book.Return();
        }
    }
}
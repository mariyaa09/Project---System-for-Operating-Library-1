﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project___System_of_Operating_Library
{
    public class BookNotBorrowedException : Exception
    {
        public BookNotBorrowedException(string message) : base(message) { }
    }
}

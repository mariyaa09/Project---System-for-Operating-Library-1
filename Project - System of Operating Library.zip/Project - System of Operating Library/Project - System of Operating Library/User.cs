﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project___System_of_Operating_Library
{
    public abstract class User
    {
        protected string Name;

        public User(string name)
        {
            Name = name;
        }

        public abstract void BorrowBook(Library library, string title);
        public abstract void ReturnBook(Library library, string title);

        public string GetName()
        {
            return Name;
        }
    }

   }
 


